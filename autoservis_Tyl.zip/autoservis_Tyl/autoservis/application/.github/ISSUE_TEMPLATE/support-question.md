---
name: Support question
about: Have a general support question on how to use the library or a CodeIgniter
  issue

---

**This Github Issue section is meant to track bugs with the library itself**
Please post generic support issues to the CodeIgniter forums or StackOverflow.
