<?php

class Model extends CI_model

{
    public function __construct() {
        parent::__construct();
    }


    function vlozeni_dat($data)  
    {  
         $this->db->insert("zamestnanci", $data);  
    }  
    public function vypis_zamestnanci()  
    {  
         $query = $this->db->query("SELECT * FROM zamestnanci ORDER BY id ASC");  
         return $query->result();  
    }  
    function smazani_dat($id){  
         $this->db->where("id", $id);  
         $this->db->delete("zamestnanci");   
    }  
    function jeden_zamestnanec($id)  
    {  
         $this->db->where("id", $id);  
         $query = $this->db->get("zamestnanci");  
         return $query;   
    }  
    function nova_data($data, $id)  
    {  
         $this->db->where("id", $id);  
         $this->db->update("zamestnanci", $data);  
    }  


    function nova_data_zakaznici($data, $id)  
    {  
         $this->db->where("idmajitele", $id);  
         $this->db->update("majitele", $data);  
    }  
    public function vypis_zakaznici()  
    {   
         $query = $this->db->query("SELECT * FROM majitele ORDER BY idmajitele ASC");  
         return $query->result();  
    }  
    function vlozeni_dat_zakaznici($data)  
    {  
         $this->db->insert("majitele", $data);  
    }  
    function vypis_jeden_zakaznik($id)  
    {  
         $this->db->where("idmajitele", $id);  
         $query = $this->db->get("majitele");   
         return $query; 
    }  

     function smazani_dat_zakaznici($id)
     {  
          $this->db->where("idmajitele", $id);  
          $this->db->delete("majitele");  
     }  

     



}

