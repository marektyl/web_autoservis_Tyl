<?php
defined('BASEPATH') OR exit ('No direct script acces allowed');


class Controller extends CI_Controller
{
   public function __construct() {
      parent::__construct();
      $this->load->library('ion_auth');
      $this->load->model('Model');
      

      if(!$this->ion_auth->logged_in())$this->load->view('pages/menu'); //když nejsem přihlášen ->menu
      else if($this->ion_auth->logged_in() && $this->ion_auth->is_admin())$this->load->view('pages/menu_admin'); //když jsem přihlášen a jsem admin ->menu_admin
   }

   
  public function index()
  {
    if(!$this->ion_auth->logged_in())$this->load->view("pages/home");
    else if($this->ion_auth->logged_in() && $this->ion_auth->is_admin())$this->load->view('pages/home_admin');
  }
 

     public function zamestnanci()  
     {    
           $this->load->library('form_validation');  
           $this->form_validation->set_rules("jmeno", "jmeno", 'required|alpha');  
           $this->form_validation->set_rules("prijmeni", "prijmeni", 'required|alpha');  

           if($this->form_validation->run())  
           {  
                $data = array(  
                     "jmeno"     =>$this->input->post("jmeno"),  
                     "prijmeni"  =>$this->input->post("prijmeni"));  

                if($this->input->post("update"))  
                {  
                     $this->Model->nova_data($data, $this->input->post("hidden_id"));  
                     redirect(base_url() . "upraveno");  
                }

                if($this->input->post("insert"))  
                {  
                     $this->Model->vlozeni_dat($data);  
                     redirect(base_url() . "vlozeno");  
                }  
           }  
           else  
           {    
               $data["vypis_zamestnanci"] = $this->Model->vypis_zamestnanci(); 
                $this->load->view("pages/zamestnanci", $data);    
           }  
     }  
     
      public function inserted()  
      {  
          $data["vypis_zamestnanci"] = $this->Model->vypis_zamestnanci(); 
          $this->load->view("pages/zamestnanci", $data);    
      }  

      public function delete_data(){  
           $id = $this->uri->segment(3);  
           $this->Model->smazani_dat($id);  
           redirect(base_url() . "odstraneno");  
      }  

      public function deleted()  
      {  
        $data["vypis_zamestnanci"] = $this->Model->vypis_zamestnanci(); 
        $this->load->view("pages/zamestnanci", $data);    
      }

      public function update_data(){  
           $user_id = $this->uri->segment(3);  
           $data["user_data"] = $this->Model->jeden_zamestnanec($user_id);  
           $data["vypis_zamestnanci"] = $this->Model->vypis_zamestnanci(); 
           $this->load->view("pages/zamestnanci", $data);  
      }  
      
      public function updated()  
      {  
          $data["vypis_zamestnanci"] = $this->Model->vypis_zamestnanci(); 
          $this->load->view("pages/zamestnanci", $data);    
      }  


     
     public function zakaznici()
     {
          $this->load->library('form_validation');  
           $this->form_validation->set_rules("jmeno", "jmeno", 'required|alpha');  
           $this->form_validation->set_rules("prijmeni", "prijmeni", 'required|alpha');
           $this->form_validation->set_rules("adresa", "adresa");  
           $this->form_validation->set_rules("telefon", "telefon");
           $this->form_validation->set_rules("email", "email");

           if($this->form_validation->run())  
           {  
                $data = array(  
                     "jmeno"     =>$this->input->post("jmeno"),  
                     "prijmeni"  =>$this->input->post("prijmeni"),
                     "adresa"    =>$this->input->post("adresa"),  
                     "telefon"   =>$this->input->post("telefon"),  
                     "email"     =>$this->input->post("email"));  

                     if($this->input->post("update"))  
                     {  
                          $this->Model->nova_data_zakaznici($data, $this->input->post("hidden_id"));  
                          redirect(base_url() . "upraveno_zakaznici");  
                     }
     
                     if($this->input->post("insert"))  
                     {  
                          $this->Model->vlozeni_dat_zakaznici($data);  
                          redirect(base_url() . "vlozeno_zakaznici");  
                     }  
                }  
                else  
                {    
                     $data["vypis_zakaznici"] = $this->Model->vypis_zakaznici(); 
                     $this->load->view("pages/zakaznici", $data);    
                }  
          }  
          
           public function inserted_zakaznici()  
           {  
               $data["vypis_zakaznici"] = $this->Model->vypis_zakaznici(); 
               $this->load->view("pages/zakaznici", $data);    
           }  
           
           public function delete_data_zakaznici(){  
                $id = $this->uri->segment(3);  
                $this->Model->smazani_dat_zakaznici($id);  
                redirect(base_url() . "odstraneno_zakaznici");  
           }  
     
           public function deleted_zakaznici()  
           {  
               $data["vypis_zakaznici"] = $this->Model->vypis_zakaznici(); 
               $this->load->view("pages/zakaznici", $data);    
           }
     
           public function update_data_zakaznici(){  
                $user_id = $this->uri->segment(3);    
                $data["user_data"] = $this->Model->vypis_jeden_zakaznik($user_id);  
                $data["vypis_zakaznici"] = $this->Model->vypis_zakaznici(); 
                $this->load->view("pages/zakaznici", $data);   
           }  
           
           public function updated_zakaznici()  
           {  
               $data["vypis_zakaznici"] = $this->Model->vypis_zakaznici(); 
               $this->load->view("pages/zakaznici", $data);    
           }  

       
     
}

