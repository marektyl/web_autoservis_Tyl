<!doctype html>
<html lang="en">
  <title>Úvodní stránka</title>
    <style>
      
      .p
      {
        text-align: center;
        margin-top: 10rem;
        font-size: 3rem;
      }
      
    </style>

    <body>
        <div class= "container">
        <p class="p">Příhlášení bylo úspěšné.</p>
    </body>
</html>