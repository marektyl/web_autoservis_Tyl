
<!doctype html>
<html lang="en">
<title>Úvodní stránka</title>
    <style>
      
    
      .h1
      {
        color: red;
        text-align: center;
        font-size: 4rem;
        margin-top: 3rem;
      }
    </style>

    <body>
    <div class="container">
      <div class="row">
        <div class="col-md">
          <h1 class="h1">Autoservis</h1>
          <img  src="https://auto-mania.cz/fanousci-rychle-a-zbesile-a-paula-walkera-by-meli-zbystrit-na-prodej-je-jeho-filmova-toyota-supra/1994-toyota-supra-2/" alt="img" width=100% height="720">
        </div>
      </div>
    </div>
    </body>
</html>